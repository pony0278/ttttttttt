import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import {createPinia} from 'pinia'
import { HomeFilled, Money, InfoFilled,ArrowDown, IceCreamRound } from "@element-plus/icons-vue";


const app = createApp(App)

const icons = {
    "HomeFilled":HomeFilled,
    "Money":Money,
    "InfoFilled":InfoFilled,
    "arrow-down":ArrowDown,
    "IceCreamRound":IceCreamRound
}

for (const [key,value] of Object.entries(icons)) {
    app.component(key,value)
}

// app.use(ElementPlus)
app.use(createPinia())
app.use(router)
app.mount('#app')
