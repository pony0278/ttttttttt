<template>
  <div class="container-fluid"></div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
