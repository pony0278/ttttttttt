<template>
  <div class="login">
    <section class="form-container">
      <div class="manage-tip">
        <span class="title">管理系統</span>
        <el-form
          :rules="rules"
          ref="ruleFormRef"
          :model="loginUser"
          class="loginForm"
          label-width="80px"
        >
          <el-form-item label="信箱" prop="email">
            <el-input
              v-model="loginUser.email"
              placeholder="請輸入信箱"
            ></el-input>
          </el-form-item>
          <el-form-item label="密碼" prop="password">
            <el-input
              v-model="loginUser.password"
              placeholder="請輸入密碼"
              type="password"
            ></el-input>
          </el-form-item>

          <el-form-item>
            <el-button @click="handleSubmit(ruleFormRef)" class="submit-btn"
              >登入</el-button
            >
          </el-form-item>
        </el-form>
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from "vue";
import { Type, registerRulesType, userType } from "../utils/types";
import { FormInstance } from "element-plus";
import axios from "../utils/http";
import {
  createRouter,
  createWebHistory,
  useRouter,
  createRouterMatcher,
} from "vue-router";
import jwt_decode from "jwt-decode";
import { useAuthStore } from "../store";
import { GetRouter } from "../store/dynamicRouter";
import { el } from "element-plus/lib/locale";

const ruleFormRef = ref<FormInstance>();
const router = useRouter();
const store = useAuthStore();
const setRouter = GetRouter();

const loginUser = ref<Type>({
  email: "",
  password: "",
});

const rules = reactive<registerRulesType>({
  email: [
    {
      type: "email",
      required: true,
      message: "信箱不正確",
      trigger: "blur",
    },
  ],
  password: [
    { required: true, message: "密碼不能為空", trigger: "blur" },
    { min: 6, max: 30, message: "密碼長度有錯", trigger: "blur" },
  ],
});

const handleSubmit = (formEl: FormInstance | undefined) => {
  if (!formEl) return;
  formEl.validate(async (valid: boolean) => {
    if (valid) {
      const { email, password } = loginUser.value;
      const response = await axios.get(
        `http://localhost:5000/login?email=${email}&password=${password}`
      );
      const user = response.data[0];

      if (user && user.success) {
        localStorage.setItem("token", user.token);

        // 解析token
        const decode: userType = jwt_decode(user.token);

        store.setAuth(!!decode);
        store.setUser(decode);

        let i = [];
        i.push(decode);
        let y: any = [];
        i.forEach((e) => {
          let c = JSON.parse(e.permissions);
          y.push(c);
        });
        setRouter.addrouters(y);

        // @ts-ignore
        ElMessage({
          message: "登入成功.",
          type: "success",
        });
        router.push("/");
      }
    } else {
      return false;
    }
  });
};
</script>

<style scoped></style>
