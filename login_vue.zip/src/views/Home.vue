<template>
  <div class="home">
    <Navbar />
    <Sidebar />
    <div class="routerView">
      <router-view></router-view>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from "vue";
import { onMounted } from "vue";
import axios from "../utils/http";
import { Type, registerRulesType, userType } from "../utils/types";
import { useAuthStore } from "../store";

const store = useAuthStore();
onMounted(async () => {
  try {
    // const data = await axios.get(`http://localhost:5000/login?email=${email}&password=${password}`);
    // store.setUser(data.data);
    // console.log(data);
  } catch (error) {
    console.log(error);
  }
});
</script>

<style scoped>
.home {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: auto;
}
.routerView {
  position: absolute;
  top: 4rem;
  left: 10rem;
  width: calc(100% - 10rem);
  height: calc(100% - 4rem);
}
</style>
