<template>
  <div
    class="d-flex flex-column flex-grow-1 flex-shrink-1 text-white border-light shadow min-vh-100 h-auto OnlyWidth"
  >
    <div class="flex-column text-center">
      <template v-for="(menu, index) in menus" :key="menu.path">
        <div
          class="OnlyHover p-3"
          data-bs-toggle="collapse"
          :data-bs-target="'#collapse' + index"
        >
          <span class="weight"> {{ menu.name }} </span>
        </div>
        <ul class="collapse text-small shadow-sm p-0" :id="'collapse' + index">
          <li
            v-for="(item, index) in menu.children"
            :key="index"
            :index="item.path"
          >
            <router-link :to="item.path">{{ item.path }}</router-link>
          </li>
        </ul>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from "vue";
import { useAuthStore } from "../store";
import { GetRouter } from "../store/dynamicRouter";
import {
  createRouter,
  createWebHistory,
  useRouter,
  createRouterMatcher,
} from "vue-router";

const store: any = useAuthStore();
const datas = JSON.parse(store.user.permissions);
const dr = GetRouter().routers;

const menus = computed(() => {
  let dynamicMenus: any = [];
  datas.Classifications.forEach((Classification: any) => {
    let chid: any = [];
    Object.entries(Classification.Permissionlist).forEach(([key, value]) => {
      chid.push({
        path: key,
        name: `${key}組件`,
      });
    });
    let titleName = Classification.ClassificationName;
    dynamicMenus.push({
      name: titleName,
      path: Classification.ClassificationName,
      children: chid,
    });
  });

  return dynamicMenus;
});
const router = useRouter();
const route = router.getRoutes();
let fatherRouter = route.find((r) => r.name === "Home");
if (fatherRouter) {
  const dynamicRouters: any = useAuthStore();
  const datas = JSON.parse(dynamicRouters.user.permissions);
  let chid: any = [];
  datas.Classifications.forEach((Classification: any) => {
    Object.entries(Classification.Permissionlist).forEach(([key, value]) => {
      chid.push({
        name: key,
        path: key,
      });
    });
  });
  chid.forEach((element: { path: any; name: any }) => {
    router.addRoute("Home", {
      path: element.name,
      component: () => import(`../views/${element.name}.vue`),
    });
  });
}
</script>

<style scoped>
.OnlyWidth {
  width: 10rem;
  background-color: #006666;
}
.weight {
  font-weight: 900;
  font-size: x-large;
}
.OnlyHover:hover {
  cursor: pointer;
  background-color: blue;
}
</style>
