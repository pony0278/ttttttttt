<template>
  <nav class="navbar navbar-expand-lg shadow bg-color">
    <div class="container-fluid">
      <router-link class="navbar-brand fw-bold text-white" to="/"
        >聯邦網通管理系統</router-link
      >
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link">已登入</a>
        </li>
        <li class="nav-item">
          <button class="btn btn-outline-success" @click="logout()">
            登出
          </button>
        </li>
      </ul>
    </div>
  </nav>
</template>

<script setup lang="ts">
import router from "../router";
import { useAuthStore } from "../store";

const store: any = useAuthStore();

const handleDropdown = (item: string) => {
  switch (item) {
    case "logout":
      logout();
      break;
  }
};

const logout = () => {
  localStorage.removeItem("token");

  store.setAuth(false);
  store.setUser(null);

  router.push("/login");
};
</script>

<style scoped>
.bg-color {
  background-color: rgb(40, 0, 0);
}
</style>
