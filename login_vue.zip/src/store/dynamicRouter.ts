import { defineStore } from "pinia";
import { routerss } from "../utils/types";

export const GetRouter = defineStore("Routers", {
  state: () => {
    return { routers: [] };
  },
  getters: {},
  actions: {
    addrouters(data: Array<routerss>) {
      data.forEach((e) => {
        e.Classifications.forEach((es) => {
          console.log(es.Permissionlist);
        });
      });
    },
  },
});
